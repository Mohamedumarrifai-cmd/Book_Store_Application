package com.example.BookStoreApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
